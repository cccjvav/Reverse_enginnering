@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
    py -3 apply_community.py
    goto finished
)
python --version >nul 2>nul
if not errorlevel 1 (
    python apply_community.py
    goto finished
)
echo Python 3.10 or later is required. Install it from python.org with Tcl/Tk.
:finished
pause
